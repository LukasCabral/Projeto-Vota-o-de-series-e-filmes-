document.getElementById('formCadastro').addEventListener('submit', async e => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const dados = Object.fromEntries(formData);
  await fetch('/api/filmes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  });
  alert('Cadastro realizado!');
  window.location.href = 'index.html';
});
