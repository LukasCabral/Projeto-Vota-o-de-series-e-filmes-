async function carregarFilmes() {
  const res = await fetch('/api/filmes');
  const filmes = await res.json();
  const lista = document.getElementById('lista-filmes');
  lista.innerHTML = '';
  filmes.forEach(f => {
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      <img src="${f.imagem}" alt="${f.titulo}">
      <div class="card-content">
        <h3>${f.titulo}</h3>
        <p><strong>Gênero:</strong> ${f.genero}</p>
        <p>${f.descricao || ''}</p>
        <p>👍 ${f.gostei} | 👎 ${f.naogostei}</p>
        <button onclick="votar(${f.id}, 'gostei')">Gostei</button>
        <button onclick="votar(${f.id}, 'naogostei')">Não Gostei</button>
      </div>
    `;
    lista.appendChild(div);
  });
}

async function votar(id, tipo) {
  await fetch(`/api/votar/${id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tipo })
  });
  carregarFilmes();
  carregarTotais();
}

async function carregarTotais() {
  const res = await fetch('/api/totais');
  const { totalGostei, totalNaoGostei } = await res.json();
  document.getElementById('totalGostei').textContent = totalGostei;
  document.getElementById('totalNaoGostei').textContent = totalNaoGostei;
}

carregarFilmes();
carregarTotais();
