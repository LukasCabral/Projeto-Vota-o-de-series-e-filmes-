import express from "express";
import cors from "cors";
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import { join } from "path";
import { fileURLToPath } from "url";

const __dirname = fileURLToPath(new URL(".", import.meta.url));
const DB_FILE = join(__dirname, "server_db.json");

const adapter = new JSONFile(DB_FILE);
const db = new Low(adapter, { filmes: [], votos: [] });

await db.read();
db.data ||= { filmes: [], votos: [] };

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(join(__dirname, "public")));

// Listar filmes
app.get("/api/filmes", (req, res) => {
  res.json(db.data.filmes);
});

// Cadastrar novo filme/série
app.post("/api/filmes", async (req, res) => {
  const { titulo, genero, descricao, imagem } = req.body;
  if (!titulo || !genero || !imagem) {
    return res.status(400).json({ error: "Campos obrigatórios: titulo, genero, imagem" });
  }
  const novo = {
    id: Date.now(),
    titulo,
    genero,
    descricao: descricao || "",
    imagem,
    gostei: 0,
    naogostei: 0
  };
  db.data.filmes.push(novo);
  await db.write();
  res.json(novo);
});

// Votar (permitir apenas 1 voto por IP para cada filme)
app.post("/api/votar/:id", async (req, res) => {
  const { id } = req.params;
  const { tipo } = req.body; // "gostei" ou "naogostei"
  const ip = req.ip; // IP do usuário

  const filme = db.data.filmes.find(f => f.id == id);
  if (!filme) {
    return res.status(404).json({ error: "Item não encontrado" });
  }

  // Verificar se o usuário já votou neste filme
  const jaVotou = db.data.votos.some(v => v.ip === ip && v.filmeId == id);
  if (jaVotou) {
    return res.status(403).json({ error: "Você já votou neste filme" });
  }

  if (tipo === "gostei") {
    filme.gostei++;
  } else if (tipo === "naogostei") {
    filme.naogostei++;
  } else {
    return res.status(400).json({ error: "Tipo de voto inválido" });
  }

  // Registrar voto
  db.data.votos.push({ ip, filmeId: id });

  await db.write();
  res.json(filme);
});

// Totais gerais
app.get("/api/totais", (req, res) => {
  const totalGostei = db.data.filmes.reduce((sum, f) => sum + f.gostei, 0);
  const totalNaoGostei = db.data.filmes.reduce((sum, f) => sum + f.naogostei, 0);
  res.json({ totalGostei, totalNaoGostei });
});

const PORT = 3000;
app.listen(PORT, () => console.log("Servidor rodando na porta " + PORT));
